window.APP_VERSION = "v55", window.CLIENT_VERSION = "android", document.addEventListener("DOMContentLoaded", function() {
loadscript("lib-forum.js", function() {
loadscript("android-common-forum.js", function() {
setExtra();
});
});
}, !1);